# crear_yaml.py
import os
from pathlib import Path

# Obtener la ruta absoluta
ruta_base = Path("mi_dataset_enojo").absolute()

# Contenido del archivo data.yaml
contenido = f"""path: {ruta_base}
train: train/images
val: val/images
nc: 4
names: ['bateria', 'vidrio_roto', 'basura', 'objeto_roto']
"""

# Guardar el archivo
with open(ruta_base / "data.yaml", "w", encoding="utf-8") as f:
    f.write(contenido)

print(f"✅ Archivo creado: {ruta_base / 'data.yaml'}")
print("\nContenido:")
print(contenido)

# Verificar que existe
if (ruta_base / "data.yaml").exists():
    print("✅ Verificado: el archivo existe")
else:
    print("❌ Error: no se pudo crear")