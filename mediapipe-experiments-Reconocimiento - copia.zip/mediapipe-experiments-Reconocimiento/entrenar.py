# entrenar.py
from ultralytics import YOLO
import time

print("="*50)
print("🚀 ENTRENAMIENTO PARA DETECTAR OBJETOS DE ENOJO")
print("="*50)
print(f"📊 Dataset: mi_dataset_enojo")
print(f"🎯 Clases: bateria, vidrio_roto, basura, objeto_roto")
print(f"⏱️  Esto tomará 5-15 minutos en CPU")
print("="*50 + "\n")

# Cargar modelo base
model = YOLO('yolo11s.pt')

# Entrenar
results = model.train(
    data='mi_dataset_enojo/data.yaml',
    epochs=30,
    imgsz=640,
    batch=4,
    device='cpu',
    patience=10,
    lr0=0.01,
    augment=True,
    verbose=True,
    project='entrenamiento_enojo',
    name='modelo_personalizado'
)

# Guardar modelo final
model.save('modelo_enojo_personalizado.pt')

print("\n" + "="*50)
print("✅ ENTRENAMIENTO COMPLETADO!")
print("📁 Modelo guardado: modelo_enojo_personalizado.pt")
print("="*50)